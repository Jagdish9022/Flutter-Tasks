package com.example.graph_bar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
