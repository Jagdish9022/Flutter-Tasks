import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

void main(){
  runApp(MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
      body: Padding(
        padding: EdgeInsets.all(14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Hello,"),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Vikas Sodnar",
                  style: TextStyle(fontSize: 23),
                ),
                Icon(
                  Icons.person_2_outlined,
                  size: 33,
                )
              ],
            ),
            Padding(
              padding: EdgeInsets.only(right: 280.0),
              child: SpinKitThreeBounce(
                color: Colors.green,
                size: 25.0,
              ),
            ),
            Text(
              "Your today's performance",
              style: TextStyle(fontSize: 17,decoration: TextDecoration.underline),
            ),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 100,
                  width: 100,
                  decoration: BoxDecoration(color:  Colors.pink[50],
                  borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10.0,left: 10, top: 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Orders"),
                        Text(
                          "124",
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 30),
                        )
                      ],
                    ),
                  ),
                ),

                Container(
                  height: 100,
                  width: 100,
                  decoration: BoxDecoration(color: Colors.black12,
                  borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10.0,left: 10, top: 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Leads"),
                        Text(
                          "223",
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 30),
                        )
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 100,
                  width: 100,
                  decoration: BoxDecoration(color: Colors.orange[50],
                  borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10.0,left: 10, top: 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Sale"),
                        Text(
                          "12k",
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 30),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 0,),
            Container(
              height: 200,
              width: double.infinity,
              child: Image(image: AssetImage("assets/images/image.png")),
            ),
SizedBox(height: 0,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
              Card(
                elevation: 12,
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Container(
                     child:  Row(children: [
                      Icon(Icons.person_add_alt_1),
                      Padding(
                        padding: const EdgeInsets.only(left: 5.0),
                        child: Text("New Lead"),
                      ),
                     ],)
                  ),
                ),
              ),
              Card(
                elevation: 12,
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Container(
                     child:  Row(children: [
                      Icon(Icons.assignment),
                      Padding(
                        padding: const EdgeInsets.only(left: 5.0),
                        child: Text("New Lead"),
                      ),
                     ],)
                  ),
                ),
              ),
              Card(
                elevation: 12,
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Container(
                     child:  Row(children: [
                      Icon(Icons.supervisor_account),
                      Padding(
                        padding: const EdgeInsets.only(left: 5.0),
                        child: Text("New Lead"),
                      ),
                     ],)
                  ),
                ),
              ),
            ],),
SizedBox(height: 7,),
            Expanded(
              child: Container(
                color: Colors.green[100],
              
                child: Column(
                  children: [
                    Align(alignment: Alignment.topCenter,),
                    Text("TARGETS",style: TextStyle(color: Colors.green[300], decoration: TextDecoration.underline,decorationColor: Colors.green[400]),)
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    ),
    );
  }
  
}

 