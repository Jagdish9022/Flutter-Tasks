  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Card(
                  elevation: 30,
                  child: Padding(
                    padding: const EdgeInsets.all(5),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 247, 246, 244),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.person_add,
                            color: Colors.green,
                          ),
                          SizedBox(
                            width: 3,
                          ),
                          Text(
                            "New lead",
                            style: TextStyle(
                                color: Colors.green,
                                fontWeight: FontWeight.bold),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                Card(
                  elevation: 30,
                  child: Padding(
                    padding: const EdgeInsets.all(5),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 247, 246, 244),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.calendar_month,
                            color: Color.fromARGB(255, 209, 221, 47),
                          ),
                          SizedBox(
                            width: 3,
                          ),
                          Text(
                            "New chate",
                            style: TextStyle(
                                color: Color.fromARGB(255, 212, 214, 52),
                                fontWeight: FontWeight.bold,
                                fontSize: 10),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                Card(
                  elevation: 30,
                  child: Padding(
                    padding: const EdgeInsets.all(5),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 247, 246, 244),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.people,
                            color: Color.fromARGB(255, 39, 38, 30),
                          ),
                          SizedBox(
                            width: 3,
                          ),
                          Text(
                            "Camping",
                            style: TextStyle(
                                color: const Color.fromARGB(255, 34, 39, 34),
                                fontWeight: FontWeight.bold),
                          )
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
            SizedBox(
              height: 15,
            ),
            Container(
              width: double.infinity,
              decoration:
                  BoxDecoration(color: Color.fromARGB(255, 209, 208, 205)),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'TARGETS',
                      style: TextStyle(
                        color: Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(255, 250, 248, 241)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "You mast viset to sinner route today with the amol Gite",
                          style: TextStyle(fontSize: 11),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            Container(
                              height: 100,
                              width: 100,
                              child: PieChart(
                                PieChartData(
                                    borderData: FlBorderData(),
                                    centerSpaceRadius: 5,
                                    centerSpaceColor: Colors.white,
                                    sections: [
                                      PieChartSectionData(
                                        color: Colors.white,
                                      )
                                    ]),
                              ),
                            ),
                            Text(
                              textAlign: TextAlign.center,
                              "Leades \n  0/20",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            )
                          ],
                        ),
                        Column(
                          children: [
                            Container(
                              height: 100,
                              width: 100,
                              child: PieChart(
                                PieChartData(
                                    borderData: FlBorderData(),
                                    centerSpaceRadius: 5,
                                    centerSpaceColor:
                                        Color.fromARGB(255, 255, 255, 255),
                                    sections: [
                                      PieChartSectionData(
                                        color:
                                            Color.fromARGB(255, 109, 224, 78),
                                      ),
                                      PieChartSectionData(
                                          borderSide: BorderSide.none,
                                          color: const Color.fromARGB(
                                              255, 255, 255, 255),
                                          value: 60,
                                          showTitle: false)
                                    ]),
                              ),
                            ),
                            Text(
                              "Orders \n  20/100",
                              textAlign: TextAlign.center,
                              style: TextStyle(fontWeight: FontWeight.bold),
                            )
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 100,
                              width: 100,
                              child: PieChart(
                                PieChartData(
                                    borderData: FlBorderData(),
                                    centerSpaceRadius: 5,
                                    centerSpaceColor: Colors.amber,
                                    sections: [
                                      PieChartSectionData(
                                        color: const Color.fromARGB(
                                            250, 250, 250, 250),
                                      ),
                                      PieChartSectionData(
                                          borderSide: BorderSide.none,
                                          color: Colors.amber,
                                          value: 60,
                                          showTitle: false)
                                    ]),
                              ),
                            ),
                            Text(
                              "Sales \n  12K/100k",
                              style: TextStyle(fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Container(
                height: 40,
                decoration:
                    BoxDecoration(color: Color.fromARGB(255, 101, 194, 157)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.person_add,
                      color: const Color.fromARGB(255, 221, 238, 221),
                    ),
                    Text(
                      "New lead",
                      style: TextStyle(
                          color: const Color.fromARGB(255, 232, 238, 232),
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Icon(
                      Icons.calendar_month,
                      color: Color.fromARGB(255, 134, 134, 129),
                    ),
                    SizedBox(
                      width: 3,
                    ),
                    Text(
                      "New chate",
                      style: TextStyle(
                        color: Color.fromARGB(255, 97, 97, 91),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Icon(
                      Icons.people,
                      color: Color.fromARGB(255, 66, 65, 55),
                    ),
                    SizedBox(
                      width: 3,
                    ),
                    Text(
                      "Camping",
                      style: TextStyle(
                          color: Color.fromARGB(255, 70, 77, 70),
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
            )