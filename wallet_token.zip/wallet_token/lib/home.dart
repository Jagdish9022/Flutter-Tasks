import 'dart:math';

import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          _firstRow(),
          SizedBox(
            height: 6,
          ),
          _secondRow(),
          SizedBox(
            height: 10,
          ),
          Text(
            "DWE WALLET TOKEN",
            style: TextStyle(color: Colors.grey),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "144,000,000.",
                style: TextStyle(color: Colors.white, fontSize: 30),
              ),
              Text(
                "352",
                style: TextStyle(color: Colors.grey[600], fontSize: 30),
              ),
              Text(
                " DWT",
                style: TextStyle(color: Colors.blue, fontSize: 30),
              ),
            ],
          ),
          Text(
            "-\$150",
            style: TextStyle(color: Colors.grey[700]),
          ),
          SizedBox(
            height: 10,
          ),
          _twoButtons(),
          SizedBox(
            height: 10,
          ),
          _secondTowButtons(),
        ],
      ),
    );
  }

  _firstRow() {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            decoration: BoxDecoration(
              border: Border.all(color: Color.fromARGB(255, 46, 45, 45)),
              borderRadius: BorderRadius.circular(50),
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              border: Border.all(color: Color.fromARGB(255, 65, 64, 64)),
              borderRadius: BorderRadius.circular(50),
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(
                Icons.notifications_none,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  _secondRow() {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                color: Colors.grey[800]),
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Image.asset(
                "assets/image.png",
                height: 40,
              ),
            ),
          ),
        ),
        Container(
          height: 60,
          decoration: BoxDecoration(
              color: Colors.blue[100], borderRadius: BorderRadius.circular(30)),
          child: Padding(
            padding: const EdgeInsets.only(left: 120.0),
            child: Container(
              width: 150,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      bottomLeft: Radius.circular(30)),
                  color: Colors.grey),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Text(
                      "\$0.000674",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w200),
                    ),
                    Text(
                      "+7.68 %",
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  _twoButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Container(
          width: 170,
          height: 40,
          child: TextButton(
              onPressed: () {},
              style: TextButton.styleFrom(backgroundColor: Colors.white),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.monetization_on_outlined,
                    color: Colors.black,
                  ),
                  Text(
                    " Send",
                    style: TextStyle(color: Colors.black),
                  ),
                ],
              )),
        ),
        Container(
          width: 170,
          height: 40,
          child: TextButton(
              onPressed: () {},
              style: TextButton.styleFrom(backgroundColor: Colors.grey[700]),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.monetization_on_outlined,
                    color: Colors.black,
                  ),
                  Text(
                    " Recieve",
                    style: TextStyle(color: Colors.black),
                  )
                ],
              )),
        )
      ],
    );
  }

  _secondTowButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Container(
          width: 170,
          decoration: BoxDecoration(
              color: Colors.grey[900], borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: Icon(
                    Icons.arrow_outward,
                    color: Colors.white,
                  ),
                ),
                Align(
                    alignment: Alignment.bottomLeft,
                    child: Text(
                      "Token Info",
                      style: TextStyle(color: Colors.white),
                    )),
              ],
            ),
          ),
        ),
        Container(
          width: 170,
          decoration: BoxDecoration(
              color: Colors.grey[900], borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: Icon(
                    Icons.arrow_outward,
                    color: Colors.white,
                  ),
                ),
                Align(
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    "Swap",
                    style: TextStyle(color: Colors.white),
                  ),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }
}
