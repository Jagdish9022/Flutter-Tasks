package com.example.facebook_loginpage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
