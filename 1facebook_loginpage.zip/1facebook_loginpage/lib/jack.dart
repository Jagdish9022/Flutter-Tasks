import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Jack extends StatelessWidget {
  const Jack({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Color.fromARGB(255, 243, 237, 241),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 250.0, right: 60),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "facebook",
                    style: TextStyle(
                      fontSize: 50,
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    "Facebook helps you connect and share ",
                    style: TextStyle(
                      fontSize: 25,
                    ),
                  ),
                  Text(
                    "with the people in your life.",
                    style: TextStyle(
                      fontSize: 25,
                    ),
                  )
                ],
              ),
            ),
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 200.0),
                  child: Card(
                    elevation:25.0 ,
                    child: Container(
                      height: 350,
                      width: 400,
                      
                      color: Colors.white,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 10.0),
                        child: Column(
                          children: [
                            Container(
                              width: double.infinity,
                              child: Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextField(
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: Colors.black)),
                                    labelText: "Email address or phone number",
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              width: double.infinity,
                              child: Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextField(
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    labelText: "password",
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.blue,
                                ),
                                width: double.infinity,
                                height: 45,
                                child: TextButton(
                                  style: ButtonStyle(),
                                  onPressed: () {},
                                  child: Text(
                                    "Log In",
                                    style: TextStyle(
                                        fontSize: 30, color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                            Text(
                              "Forgotten password?",
                              style: TextStyle(color: Colors.blue),
                            ),
                           const Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Divider(),
                            ),
                          const  SizedBox(
                              height: 10,
                            ),
                            Container(
                                width: 200,
                                height: 40,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    color: Colors.green),
                                child: TextButton(
                                    onPressed: () {},
                                    child:const Text(
                                      "Create new account",
                                      style: TextStyle(
                                          fontSize: 17, color: Colors.white),
                                    ))),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20,),
                const Row(
                  children: [
                    Text(
                      "Create a Page ",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text("for a celebrity, brand or business.")
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
