import 'package:facebook_loginpage/jack.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Jack(),
  ));
}
 