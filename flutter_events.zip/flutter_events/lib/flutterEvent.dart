import 'package:flutter/material.dart';
import 'package:flutter_events/fluttermain.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      width: double.infinity,
      child: DecoratedBox(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: NetworkImage("assets/background.png"),
                fit: BoxFit.cover)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image(
                image: AssetImage(
                  "assets/logo.png",
                ),
                height: 70,
              ),
              Row(
                children: [
                  Text(
                    "Flutter",
                    style: TextStyle(fontSize: 24, color: Colors.white),
                  ),
                  Text(
                    "Events",
                    style: TextStyle(fontSize: 24, color: Colors.amber),
                  ),
          
                ],
              ),
              Text("There's a lot happening around you! Our",style: TextStyle(color: Colors.white),),
              Text("mission is to provide what's happening near",style: TextStyle(color: Colors.white)),
              Text("you!",style: TextStyle(color: Colors.white)),
              
              Container(
                width: 150,
                child: TextButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => MainPage(),));
                }, child: Row(children: [Text("Get Stareted   ",style: TextStyle(color: Colors.white),),Icon(Icons.arrow_forward,color: Colors.white)],)))
          
            ],
          ),
        ),
      ),
    ));
  }
}

