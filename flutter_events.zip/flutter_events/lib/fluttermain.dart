import 'package:date_picker_timeline/date_picker_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class MainPage extends StatelessWidget {
  const MainPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey[800],
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.blueGrey[800],
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Image(
                  image: AssetImage("assets/logo.png"),
                  height: 35,
                ),
                Row(
                  children: [
                    Text(
                      "Flutter",
                      style: TextStyle(fontSize: 22, color: Colors.white),
                    ),
                    Text(
                      "Events",
                      style: TextStyle(fontSize: 22, color: Colors.amber),
                    ),
                  ],
                ),
              ],
            ),
            Row(
              children: [
                Icon(
                  Icons.notifications_none,
                  color: Colors.white,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.border_all,
                    color: Colors.white,
                  ),
                )
              ],
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: const EdgeInsets.only(left: 20,right: 20),
          child: Column(
            crossAxisAlignment:CrossAxisAlignment.start ,
            children: [_profile(), _calender(), _allEvents(),_popularEvents()],
          ),
        ),
      ),
    );
  }

  _profile() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Hello, Jagdish!",
              style: TextStyle(color: Colors.white, fontSize: 20),
            ),
            Text("Let's explore What's Happening nearby",
                style: TextStyle(
                  color: Colors.white,
                ))
          ],
        ),
        Image.asset(
          "assets/download.png",
          height: 60,
        )
      ],
    );
  }

  _calender() {
    return  Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                DatePicker(
                  monthTextStyle: TextStyle(fontSize: 0),
                  DateTime.now(),
                  initialSelectedDate: DateTime.now(),
                  selectionColor: Colors.amber,
                  selectedTextColor: Colors.black,
                  width: 50,
                  height: 90,
                  onDateChange: (date) {
                    
                  },
                ),
              ],
            );
  }

  _allEvents() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 15,),
        Text("All Events",style: TextStyle(fontSize: 20,color: Colors.white),),
        SizedBox(height: 13,),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              height: 100,
              width: 100,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.blueGrey[600]),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.mic_external_on_outlined,
                    color: Colors.white,
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Text(
                    "Concert",
                    style: TextStyle(color: Colors.white),
                  )
                ],
              ),
            ),
            Container(
              height: 100,
              width: 100,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.blueGrey[600]),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.sports_tennis_outlined,
                    color: Colors.white,
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Text(
                    "Sports",
                    style: TextStyle(color: Colors.white),
                  )
                ],
              ),
            ),
            Container(
              height: 100,
              width: 100,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.blueGrey[600]),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.school,
                    color: Colors.white,
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Text(
                    "Education",
                    style: TextStyle(color: Colors.white),
                  )
                ],
              ),
            ),
          ],
        )
      ],
    );
  }

  _popularEvents(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 10,),
      Text("Popular Events",style: TextStyle(fontSize: 20,color: Colors.white),),
      
      Container(
        decoration: BoxDecoration(
          color: Colors.blueGrey[500],
          borderRadius: BorderRadius.circular(14)
        ),
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Sports Meet in Galaxy",style: TextStyle(color: Colors.white,fontSize: 16),), 
                  Text("Field",style: TextStyle(color: Colors.white,fontSize: 16),),
                  Row(
                    children: [
                      Icon(Icons.calendar_month,color: Colors.white,size: 14,),
                      Text(" Jan 12, 2019",style: TextStyle(color: Colors.white),)
                    ],
                  ),
                  Row(children: [
                    Icon(Icons.location_on,color: Colors.white,size: 14,),
                    Text(" Greenfields, sector 42, Faridabad",style: TextStyle(fontSize: 13,color: Colors.white),)
                  ],)
                ],
              ),
              Image.asset("assets/images.png",fit: BoxFit.cover,height: 100,width: 90,)
            ],
          ),
        ),
      ),
SizedBox(height: 7,),
      Container(
        decoration: BoxDecoration(
          color: Colors.blueGrey[500],
          borderRadius: BorderRadius.circular(14)
        ),
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Arts & Meet in Street Plaza ",style: TextStyle(color: Colors.white,fontSize: 16),), 
                  Row(
                    children: [
                      Icon(Icons.calendar_month,color: Colors.white,size: 14,),
                      Text(" Jan 12, 2019",style: TextStyle(color: Colors.white),)
                    ],
                  ),
                  Row(children: [
                    Icon(Icons.location_on,color: Colors.white,size: 14,),
                    Text(" Galaxyfield, sector 22, Faridabad",style: TextStyle(fontSize: 13,color: Colors.white),)
                  ],)
                ],
              ),
              Image.asset("assets/images2.png",fit: BoxFit.cover,height: 100,width: 90,)
            ],
          ),
        ),
      ),
      SizedBox(height: 7,),
      Container(
        decoration: BoxDecoration(
          color: Colors.blueGrey[500],
          borderRadius: BorderRadius.circular(14)
        ),
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Youth Music in Gwalior",style: TextStyle(color: Colors.white,fontSize: 16),), 
                  Text("Field",style: TextStyle(color: Colors.white,fontSize: 16),),
                  Row(
                    children: [
                      Icon(Icons.calendar_month,color: Colors.white,size: 14,),
                      Text(" Jan 12, 2019",style: TextStyle(color: Colors.white),)
                    ],
                  ),
                  Row(children: [
                    Icon(Icons.location_on,color: Colors.white,size: 14,),
                    Text(" Greenfields, sector 22, Faridabad",style: TextStyle(fontSize: 13,color: Colors.white),)
                  ],)
                ],
              ),
              Image.asset("assets/images3.png",fit: BoxFit.cover,height: 100,width: 90,)
            ],
          ),
        ),
      ),
    ],);
  }
}
