import 'package:flutter/material.dart';


class Evant extends StatelessWidget {
  const Evant({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    
      body:Container(width: double.infinity,
      
        child: DecoratedBox(
          
          decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage('asset/background.png'),fit: BoxFit.cover)
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center
          ,
          children: [
            Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.only(left: 20),
                child: Image.asset("asset/ulogi.png",height: 70,),
              )),
          Padding(
            padding: const EdgeInsets.only(left: 30),
            child: Row(
              children: [
                Text('Flutter',style: TextStyle(color: Colors.white,fontSize: 23,fontWeight: FontWeight.w600),),
                   Text('Events',style: TextStyle(color: Colors.yellow[800],fontSize: 23,fontWeight: FontWeight.w600),)
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('There s a lot happening around you! Our',style: TextStyle(fontSize: 15,color: Colors.white),),
                Text('mission is to provide whats happening near',style: TextStyle(fontSize: 15,color: Colors.white),),
          Text("you!",style: TextStyle(fontSize: 15,color: Colors.white),),
             TextButton(onPressed: (){
              // Navigator.push(context,MaterialPageRoute(builder: (context) => evant2(),));
             }, child: Text('Get Started →',style: TextStyle(fontSize: 20,color: Colors.white),))
       
            ],
          ),
        
        
          ],
        ),
        ),
      )
    );
  }

}
