package com.example.flutter_events

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
