import 'dart:math';

void main() {
  var random = Random();
  int number = 100000 + random.nextInt(999999);
  print(number);
}
