import 'package:flutter/material.dart';
import 'package:signup/forgot.dart';


class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _usernameRequired = false;
  bool _passwordRequired = false;
  bool _passwordVisible = true;

  get decoration => null;
  void _showLoginSuccessDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Login Successful"),
          content: Text("You have successfully logged in!"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _usernameController.clear();
                _passwordController.clear();
              },
              child: Text("OK"),
            ),

          ],
        );
      },
    );
  }



  void _showPassword() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Alert"),
            content: Text("Your Usernmae or Password is wrong!"),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text("OK"),
              )
            ],
            
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 58, 108, 214),
      appBar: AppBar(
          title: Center(child: const Text("Login Page")),
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 30.0,
          ),
          backgroundColor: Colors.black54),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: NetworkImage("../assets/images/image1.jpg"),
              fit: BoxFit.cover,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: TextField(
                  controller: _usernameController,
                  onChanged: (value) {
                    setState(() {
                      _usernameRequired = false;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Username',
                    hintStyle: TextStyle(color: Colors.white),
                    errorText:
                        _usernameRequired ? 'Username is required' : null,
                    errorStyle: TextStyle(fontSize: 17.0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    filled: true,
                    fillColor: Colors.black.withOpacity(0.5),
                  ),
                  style: TextStyle(color: Colors.white, fontSize: 20.0),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: TextField(
                  controller: _passwordController,
                  onChanged: (value) {
                    setState(() {
                      _passwordRequired = false;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Password',
                    hintStyle: TextStyle(color: Colors.white, fontSize: 20.0),
                    errorText:
                        _passwordRequired ? 'Password is required' : null,
                    errorStyle: TextStyle(fontSize: 17.0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    filled: true,
                    fillColor: Colors.black.withOpacity(0.5),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _passwordVisible
                            ? Icons.visibility_off
                            : Icons.visibility,
                        color: Colors.white,
                      ),
                      onPressed: () {
                        setState(() {
                          _passwordVisible = !_passwordVisible;
                        });
                      },
                    ),
                  ),
                  obscureText: _passwordVisible,
                  style: TextStyle(color: Colors.white),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10.0),
                    child: ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _usernameController.text.isEmpty
                              ? _usernameRequired = true
                              : _usernameRequired = false;
                          _passwordController.text.isEmpty
                              ? _passwordRequired = true
                              : _passwordRequired = false;
                        });
                        if (_usernameController.text.contains("Jagdish") &&
                            _passwordController.text.contains("1234")) {
                          _showPassword();
                          print("Uesrname : ${_usernameController.text}");
                          print("Can't Access Password ...........");
                        } else if (!(_usernameController.text
                                    .contains("Jagdish") &&
                                _passwordController.text.contains("1234")) &&
                            (_passwordController.text.isNotEmpty &&
                                _usernameController.text.isNotEmpty)) {
                          _showLoginSuccessDialog();
                        }
                      },
                      child: Text(
                        'Login',
                        style: TextStyle(fontSize: 20.0, height: 2.0),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 20.0),
                    child: TextButton(
                      onPressed: () {
                        _usernameController.clear();
                        _passwordController.clear();
                        setState(() {
                          _usernameRequired = false;
                          _passwordRequired = false;
                        });
                      },
                      child: Text(
                        'Reset',
                        style: TextStyle(
                          fontSize: 24.0,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 30),
              Padding(
                padding: const EdgeInsets.only(right: 200.0),
                child: TextButton(
                  onPressed: () {
                    MyApp();
                  },
                  child: Text(
                    'Forgot Password?',
                    style: TextStyle(
                        color: Color.fromARGB(255, 167, 11, 154),
                        fontSize: 20.0),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}