import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: StatsPage(),
    );
  }
}

class StatsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('STATS'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 16.0,
                mainAxisSpacing: 16.0,
                children: [
                  StatCard(
                    color: Colors.red,
                    title: 'Heart Rate',
                    value: '124 bpm',
                    subText: '80-120 Healthy',
                    icon: Icons.favorite,
                  ),
                  StatCard(
                    color: Colors.blue,
                    title: 'Sleep',
                    value: '8 h 42 m',
                    subText: 'Deep Sleep\n5 h 13 m',
                    icon: Icons.bedtime,
                  ),
                  StatCard(
                    color: Colors.orange,
                    title: 'Energy Burn',
                    value: '583 kcal',
                    subText: 'Daily Goal\n900 kcal',
                    icon: Icons.local_fire_department,
                  ),
                  StatCard(
                    color: Colors.teal,
                    title: 'Steps',
                    value: '16,741',
                    subText: 'Daily Goal\n20,000 Steps',
                    icon: Icons.directions_walk,
                  ),
                  StatCard(
                    color: Colors.purple,
                    title: 'Running',
                    value: '5,3 km',
                    subText: 'Daily Goal\n10 km',
                    icon: Icons.directions_run,
                  ),
                  StatCard(
                    color: Colors.green,
                    title: 'Cycling',
                    value: '12,5 km',
                    subText: 'Daily Goal\n20 km',
                    icon: Icons.directions_bike,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.insert_chart), label: 'Stats'),
          BottomNavigationBarItem(icon: Icon(Icons.card_giftcard), label: 'Rewards'),
          BottomNavigationBarItem(icon: Icon(Icons.flag), label: 'Goals'),
        ],
        currentIndex: 1,
        onTap: (index) {},
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  final Color color;
  final String title;
  final String value;
  final String subText;
  final IconData icon;

  StatCard({required this.color, required this.title, required this.value, required this.subText, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.white),
              Spacer(),
            ],
          ),
          SizedBox(height: 8.0),
          Text(
            value,
            style: TextStyle(color: Colors.white, fontSize: 24.0, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8.0),
          Text(
            title,
            style: TextStyle(color: Colors.white, fontSize: 16.0, fontWeight: FontWeight.w600),
          ),
          SizedBox(height: 8.0),
          Text(
            subText,
            style: TextStyle(color: Colors.white, fontSize: 12.0),
          ),
        ],
      ),
    );
  }
}
