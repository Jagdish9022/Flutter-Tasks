import 'package:flutter/material.dart';
import 'package:third_page/second.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyApp(),
  ));
}
