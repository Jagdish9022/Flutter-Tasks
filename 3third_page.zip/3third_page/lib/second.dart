import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            SizedBox(
              height: 12,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.location_on_rounded,
                      size: 30,
                    ),
                    Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(right: 15.0),
                          child: Text("Express Delivery"),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 9.0),
                          child: Text(
                            "Deepolie Street, 42",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(),
                        )
                      ],
                    )
                  ],
                ),
                Row(
                  children: [Icon(Icons.search), Icon(Icons.notifications)],
                )
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              height: 50,
              decoration: BoxDecoration(
                  color: Color.fromARGB(255, 172, 170, 166),
                  borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(5.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    MaterialButton(
                        onPressed: () {},
                        height: 48,
                        minWidth: 150,
                        color: Colors.white,
                        child: Text("Delivery")),
                    Padding(
                      padding: const EdgeInsets.only(right: 70.0),
                      child: Text("Shop"),
                    )
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              height: 150,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                image: DecorationImage(
                  image: NetworkImage(
                      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrxR8TaBqdctTS_EkZn1QQ0-paeCJu_idD2w&s'),
                  fit: BoxFit.cover,
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    left: 16,
                    top: 16,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Level 2 in June',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          '8% on your favorite product',
                          style: TextStyle(color: Colors.white),
                        ),
                        SizedBox(height: 30),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              height: 20,
                              decoration: BoxDecoration(color: Colors.white),
                              child: Text(
                                '1,300 bonuses',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 170.0),
                              child: Container(
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(50)),
                                  child:
                                      Icon(Icons.arrow_forward_ios_outlined)),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10,),
             SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: 150,
                      width: 180,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Stack(children: [
                          Align(
                                alignment: Alignment.topRight,
                                child: Container(
                                  height: 90,
                                  width: 60,
                                  
                                  child: Image(image: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzojxjclj_4ioTHYYPCj66BQH1Th2zJekLxw&s')),
                                ),
                              ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text("Prepared\nfood",style: TextStyle(fontSize: 21,fontWeight: FontWeight.w900),))]),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: 150,
                      width: 180,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                      ),
                       child: Padding(
                         padding: const EdgeInsets.all(8.0),
                         child: Stack(
                           children: [
                            Align(
                                alignment: Alignment.topRight,
                                child: Container(
                                  height: 90,
                                  width: 60,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50)
                                  ),
                                  child: Image(image: NetworkImage('https://images.herzindagi.info/image/2024/Jan/Grilled-Vegetable-Salad.jpg')),
                                ),
                              ),
                             Align(
                              alignment: Alignment.topLeft,
                              child: Text("Meat and\nPolutry",style: TextStyle(fontSize: 21,fontWeight: FontWeight.w900),)),
                              
                           ],
                         ),
                       ),
                    ),
                  )
                ],
              ),
            )
            
          ],
        ),
      ),
    );
  }
}
