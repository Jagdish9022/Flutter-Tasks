package com.example.popular_books

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
