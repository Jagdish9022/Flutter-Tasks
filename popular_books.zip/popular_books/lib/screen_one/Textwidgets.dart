import 'package:flutter/material.dart';

class Textwidgets extends StatelessWidget {
  final String? data;
  final double? fontSize;
  final FontWeight? fontWeight;

  const Textwidgets({
    super.key,
    this.data,
    this.fontSize, this.fontWeight,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      "$data",
      style: TextStyle(fontSize: fontSize,fontWeight: fontWeight),
    );
  }
}
