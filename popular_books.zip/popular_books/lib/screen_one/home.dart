import 'package:flutter/material.dart';
import 'package:popular_books/screen_one/Textwidgets.dart';
import 'package:popular_books/screen_one/container_ho.dart';
import 'package:popular_books/screen_one/custom_bottons.dart';
import 'package:popular_books/screen_one/custom_container.dart';

class Screen1 extends StatelessWidget {
  const Screen1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Row(
        children: [
          Icon(Icons.border_all_rounded),
          Spacer(),
          Icon(Icons.search),
          SizedBox(
            width: 20,
          ),
          Icon(Icons.notifications)
        ],
      )),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Textwidgets(
                data: "Popluler books",
                fontSize: 24,
                fontWeight: FontWeight.w600,
              ),
              SizedBox(
                height: 20,
              ),
              SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      Custom_Container(
                        height: 120,
                        width: 280,
                        data1: "All Romance \nBooks",
                        textcolor: Colors.white,
                        data3: "e-books",
                        fontSize: 18,
                        assetName: "assets/image1.png",
                        image_height: 100,
                        bgColors: Colors.blue[900],
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Custom_Container(
                        height: 120,
                        width: 280,
                        data1: "Favorite \nBooks",
                        textcolor: Colors.white,
                        data3: "",
                        fontSize: 18,
                        assetName: "assets/image1.png",
                        image_height: 100,
                        bgColors: Colors.lightBlue[200],
                      ),
                    ],
                  )),
              SizedBox(
                height: 15,
              ),
              Row(
                children: [
                  CustomBottons(
                    data: "New",
                    textcolor: Colors.white,
                    bgcolors: Colors.amber,
                  ),
                  Spacer(),
                  CustomBottons(
                    data: " Populer",
                    textcolor: Colors.white,
                    bgcolors: Colors.red,
                  ),
                  Spacer(),
                  CustomBottons(
                    data: "Trending",
                    textcolor: Colors.white,
                    bgcolors: Colors.blue,
                  ),
                  Spacer()
                ],
              ),
              CustomContainer(
                data1: "4.5",
                data2: "The Water Cure",
                assetimage: "assets/image2.png",
                data3: "by Martin Hyatt",
              ),
              CustomContainer(
                data1: "4.2",
                data2: "Peace Life         ",
                assetimage: "assets/image3.png",
                data3: "by Hezard bin",
              ),
              CustomContainer(
                data1: "3.5",
                data2: "Day remeber    ",
                assetimage: "assets/image4.png",
                data3: "by Nicholos",
              )
            ],
          ),
        ),
      ),
    );
  }
}
