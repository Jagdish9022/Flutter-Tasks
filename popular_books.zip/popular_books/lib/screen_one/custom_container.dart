import 'package:flutter/material.dart';

class CustomContainer extends StatelessWidget {
  const CustomContainer(
      {super.key, this.assetimage, this.icon, this.data1, this.data2, this.data3});
  final String? assetimage;
  final Icon? icon;
  final String? data1;
  final String? data2;
  final String? data3;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        children: [
          Align(
              alignment: Alignment.topLeft,
              child: Image(
                image: AssetImage("$assetimage"),
                fit: BoxFit.cover,
                height: 150,
                width: 100,
              )),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.star,
                    size: 16,
                    color: Colors.amber,
                  ),
                  Text("  $data1",style: TextStyle(fontSize: 14),),
                ],
              ),
              Row(
                children: [
                  Text("$data2 ",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600),),
                  SizedBox(width: 10,),
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(3.0),
                      child: Icon(
                        Icons.play_arrow,
                        color: Colors.blue,
                        size: 14,
                      ),
                    ),
                  ),
                  SizedBox(width: 8,),
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(3.0),
                      child: Icon(
                        Icons.remove_red_eye_outlined,
                        size: 14,
                      ),
                    ),
                  ),
                  SizedBox(width: 10,),
                  Icon(Icons.more_vert)
                ],
              ),
              Text("$data3",style: TextStyle(color: Colors.grey),),
              MaterialButton(onPressed: () {},
              child: Text("Home",style: TextStyle(fontSize: 10),),
              color: Colors.blue,
              minWidth: 60,
              height: 30,
              textColor: Colors.white,
              )
            ],
          )
        ],
      ),
    );
  }
}
