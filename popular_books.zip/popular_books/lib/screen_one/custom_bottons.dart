import 'package:flutter/material.dart';

class CustomBottons extends StatelessWidget {
  const CustomBottons({super.key, this.data, this.bgcolors, this.textcolor});
  final String? data;
  final Color? bgcolors;
  final Color? textcolor;
  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: () {},
      color: bgcolors,
      height: 40,
      minWidth: 100,
      textColor: textcolor,
      child: Text("$data"),
    );
  }
}
