import 'package:flutter/material.dart';

class Custom_Container extends StatelessWidget {
  const Custom_Container(
      {super.key,
      this.assetName,
      this.data1,
      this.data2,
      this.data3,
      this.height,
      this.width,
      this.image_height,
      this.image_width,
      this.bgColors,
      this.textcolor,
      this.fontSize,
      this.radius});

  final String? data1;
  final String? data2;
  final String? data3;
  final double? fontSize;
  final Color? textcolor;
  final String? assetName;
  final double? height;
  final double? width;
  final double? image_height;
  final double? image_width;
  final double? radius;
  final Color? bgColors;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        color: bgColors,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 20.0),
        child: Column(
          children: [
            Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "$data1",
                      style: TextStyle(color: textcolor, fontSize: fontSize),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      "$data3",
                      style: TextStyle(
                        color: textcolor,
                      ),
                    )
                  ],
                ),
                Spacer(),
                Image(
                  image: AssetImage("$assetName"),
                  height: image_height,
                  width: image_width,
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
