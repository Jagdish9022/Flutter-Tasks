import 'package:flutter/material.dart';
import 'package:popular_books/screen_two/icons.dart';

class Screen2 extends StatelessWidget {
  const Screen2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[600],
      body: Column(
        children: [
          CustomIcon(icon: Icons.abc)
        ],
      ),
    );
  }
}
