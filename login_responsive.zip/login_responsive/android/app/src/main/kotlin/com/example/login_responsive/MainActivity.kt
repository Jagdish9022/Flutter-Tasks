package com.example.login_responsive

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
