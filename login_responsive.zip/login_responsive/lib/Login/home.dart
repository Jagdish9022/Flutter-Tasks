import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            _image(),
            _textField(),
            _last(),
          ],
        ),
      ),
    );
  }

  _image() {
    return Padding(
      padding: EdgeInsets.only(top: 70),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image(
            image: AssetImage(
              "assets/img.png",
            ),
            height: 120,
          ),
        ],
      ),
    );
  }

  _textField() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          SizedBox(
            height: 10,
          ),
          TextField(
            decoration: InputDecoration(
              labelText: "Email/student code",
              enabledBorder: UnderlineInputBorder(
                borderSide:
                    BorderSide(color: Colors.grey), 
              ),
              suffixIcon: Icon(Icons.task_alt_rounded,color: Colors.green,),
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.green),
                
              ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          TextField(
            obscureText: true,
            decoration: InputDecoration(
              labelText: "password",
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Radio(
                      value: 1,
                      groupValue: 1,
                      onChanged: (value) {
                        value = 1;
                      }),
                  Text("Remember me")
                ],
              ),
              Text(
                "Forgot Password?",
                style: TextStyle(color: Colors.blue),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          )
        ],
      ),
    );
  }

  _last() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Container(
            height: 50,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.blue[700],
            ),
            child: TextButton(
              onPressed: () {},
              child: Text(
                "Login",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
          SizedBox(
            height: 15,
          ),
          Text(
            "or",
            style: TextStyle(fontSize: 20),
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                color: Colors.blue,
                width: 145,
                height: 40,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.network(
                      "https://png.pngtree.com/element_our/sm/20180506/sm_5aeedf03a7b81.jpg"),
                ),
              ),
              Container(
                height: 40,
                width: 145,
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Image.asset(
                    "assets/google.png",
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: 40,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Don't have an account?",
                style: TextStyle(fontSize: 16),
              ),
              Text(
                " Register now",
                style: TextStyle(color: Colors.purple, fontSize: 16),
              )
            ],
          )
        ],
      ),
    );
  }
}
