import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';

class Register extends StatelessWidget {
  const Register({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.grey[200],
        title: Row(
          children: [Icon(Icons.arrow_back_ios, size: 36)],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Column(
          children: [
            Align(
              alignment: Alignment.topLeft,
              child: Text(
                "Register",
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.w500),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            _buttons1(),
            SizedBox(
              height: 30,
            ),
            _texfield(),
            _bottum_last(),
          ],
        ),
      ),
    );
  }

  _buttons1() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
            width: 140,
            height: 40,
            color: Colors.white,
            child: TextButton(
              onPressed: () {},
              child: Text(
                "Teacher",
                style: TextStyle(color: Colors.black),
              ),
            )),
        Container(
            width: 140,
            height: 40,
            color: Colors.blue,
            child: TextButton(
              onPressed: () {},
              child: Text(
                "Student",
                style: TextStyle(color: Colors.white),
              ),
            )),
      ],
    );
  }

  _texfield() {
    return Column(
      children: [
        TextField(
          decoration: InputDecoration(labelText: "Jagdish pagar"),
          keyboardType: TextInputType.multiline,
        ),
        SizedBox(height: 14),
        TextField(
          decoration: InputDecoration(
            labelText: "",
          ),
          keyboardType: TextInputType.phone,
        ),
        SizedBox(height: 14),
        TextField(
          obscureText: true,
          decoration: InputDecoration(labelText: ""),
        ),
        SizedBox(height: 14),
        TextField(
          obscureText: true,
          decoration: InputDecoration(labelText: ""),
        ),
      ],
    );
  }

  _bottum_last() {
    return Column(
      children: [
        SizedBox(
          height: 40,
        ),
        Container(
          color: Colors.blue[700],
          width: double.infinity,
          height: 40,
          child: TextButton(
              onPressed: () {},
              child: Text(
                "Register",
                style: TextStyle(color: Colors.white),
              )),
        ),
        SizedBox(
          height: 40,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              color: Colors.blue,
              width: 145,
              height: 40,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Image.network(
                    "https://png.pngtree.com/element_our/sm/20180506/sm_5aeedf03a7b81.jpg"),
              ),
            ),
            Container(
              height: 40,
              width: 145,
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Image.asset(
                  "assets/google.png",
                ),
              ),
            )
          ],
        ),
        SizedBox(height: 40,),
        Row(
          children: [
            Text("By Registering you agree to ",style: TextStyle(fontWeight: FontWeight.w700),),
            Text("Terms and Condition",style: TextStyle(color: Colors.blue),)
          ],
        )
      ],
    );
  }
}
