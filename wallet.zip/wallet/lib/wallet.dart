import 'package:flutter/material.dart';

// ignore: must_be_immutable
class Home extends StatelessWidget {
  List data = [
    [
      Icons.lock_open_outlined,
      "Wallet",
      "Security",
      Colors.blue[200],
    ],
    [Icons.published_with_changes, "Push", "Notifications", Colors.purple[200]],
    [Icons.trending_up, "Price", "Alerts", Color.fromARGB(255, 31, 30, 30)],
    [
      Icons.live_help_outlined,
      "Help",
      "& Support",
      Color.fromARGB(255, 106, 76, 76)
    ],
    [Icons.person_2_outlined, "Acconts", " ", Colors.blue[300]],
    [Icons.help_outline_outlined, "About", " ", Colors.blueGrey],
  ];
  Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          children: [
            _firstRow(),
            Text(
              "Setting",
              style: TextStyle(color: Colors.white, fontSize: 28),
            ),
            _firstContainer(),
            SizedBox(
              height: 5,
            ),
            _seondRow(),
            SizedBox(
              height: 5,
            ),
            _lastRow()
          ],
        ),
      ),
    );
  }

  _firstRow() {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            decoration: BoxDecoration(
                border: Border.all(color: Color.fromARGB(255, 46, 45, 45)),
                borderRadius: BorderRadius.circular(50)),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(
                Icons.arrow_back_ios_new,
                size: 20,
                color: Colors.white,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              border: Border.all(color: Color.fromARGB(255, 65, 64, 64)),
              borderRadius: BorderRadius.circular(50),
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(
                Icons.notifications_none,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  _firstContainer() {
    return Container(
      width: double.infinity,
      child: GridView.builder(
        shrinkWrap: true,
        gridDelegate:
            SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(2.0),
            child: Container(
              width: 168,
              decoration: BoxDecoration(
                  color: data[index][3],
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(
                      alignment: Alignment.topRight,
                      child: Icon(
                        Icons.arrow_outward,
                        size: 23,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Icon(
                        data[index][0],
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      data[index][1],
                      style: TextStyle(color: Colors.white),
                    ),
                    Text(data[index][2], style: TextStyle(color: Colors.white))
                  ],
                ),
              ),
            ),
          );
        },
        itemCount: 6,
      ),
    );
  }

  _seondRow() {
    return Container(
      decoration: BoxDecoration(
          color: Colors.grey[800], borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Icon(
                  Icons.telegram,
                  color: Colors.white,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 6.0),
                  child: Text(
                    "Jion us on Telegram",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ),
              ],
            ),
            Icon(
              Icons.arrow_forward_ios_outlined,
              size: 14,
              color: Colors.white,
            )
          ],
        ),
      ),
    );
  }

  _lastRow() {
    return Container(
      decoration: BoxDecoration(
          color: Colors.grey[800], borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Icon(
                  Icons.person_pin_outlined,
                  color: Colors.white,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 6.0),
                  child: Text(
                    "Jion us on Discord",
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ),
              ],
            ),
            Icon(
              Icons.arrow_forward_ios_outlined,
              size: 14,
              color: Colors.white,
            )
          ],
        ),
      ),
    );
  }
}
