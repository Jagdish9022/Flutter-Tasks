import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  List data = [
    [
      Icons.lock_open_outlined,
      "Wallet",
      "Security",
      Colors.blue[200],
    ],
    [Icons.published_with_changes, "Push", "Notifications", Colors.purple[200]],
    [
      Icons.trending_up,
      "Price",
      "Alerts",
      const Color.fromARGB(255, 43, 43, 43)
    ],
    [
      Icons.live_help_outlined,
      "Help",
      "& Support",
      const Color.fromARGB(255, 106, 76, 76)
    ],
    [Icons.person_2_outlined, "Acconts", " ", Colors.blue[300]],
    [Icons.help_outline_outlined, "About", " ", Colors.blueGrey],
  ];
  Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          _firstRow(),
          Text(
            "Setting",
            style: TextStyle(color: Colors.white, fontSize: 32),
          ),
          _firstContainer(),
        ],
      ),
    );
  }

  _firstRow() {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            decoration: BoxDecoration(
                border: Border.all(color: Color.fromARGB(255, 43, 42, 42)),
                borderRadius: BorderRadius.circular(50)),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(
                Icons.arrow_back_ios_new,
                size: 20,
                color: Colors.white,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              border: Border.all(color: Color.fromARGB(255, 43, 42, 42)),
              borderRadius: BorderRadius.circular(50),
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(
                Icons.notifications_none,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  _firstContainer() {
    return Container(
      height: 620,
      width: double.infinity,
      child: GridView.builder(
        gridDelegate:
            SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(2.0),
            child: Container(
              width: 168,
              decoration: BoxDecoration(
                  color: data[index][3],
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(
                      alignment: Alignment.topRight,
                      child: Icon(
                        Icons.arrow_outward,
                        size: 23,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Icon(
                        data[index][0],
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      data[index][1],
                      style: TextStyle(color: Colors.white),
                    ),
                    Text(data[index][2], style: TextStyle(color: Colors.white))
                  ],
                ),
              ),
            ),
          );
        },
        itemCount: 6,
      ),
    );
  }
}
