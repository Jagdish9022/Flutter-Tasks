package com.example.stats

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
