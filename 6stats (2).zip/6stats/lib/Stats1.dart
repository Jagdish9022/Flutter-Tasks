import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class Stats extends StatelessWidget {
  const Stats({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Row(
              children: [
                Icon(Icons.arrow_back_ios_new_outlined),
                Padding(
                  padding: const EdgeInsets.only(left: 120.0),
                  child: Text("STATS",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: const Color.fromARGB(255, 199, 197, 197)),
              child: Row(
                children: [
                  Container(
                      width: 120,
                      decoration: BoxDecoration(),
                      child: ElevatedButton(
                        onPressed: () {},
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                        ),
                        child: Text("Day"),
                      )),
                  Padding(
                    padding: const EdgeInsets.only(left: 60.0),
                    child: Text("Week"),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                      left: 50.0,
                    ),
                    child: Text("Month"),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Container(
                  height: 160,
                  width: 160,
                  decoration: BoxDecoration(
                      color: Colors.red[400],
                      borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 10.0, right: 10, bottom: 10),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Hart Rate",
                              style: TextStyle(fontSize: 13,color: Colors.white),
                            ),
                            Container(
                              height: 40,
                              width: 40,
                              decoration: BoxDecoration(
                                  color: Color.fromARGB(31, 221, 213, 213),
                                  borderRadius: BorderRadius.circular(50)),
                              child: Padding(
                                padding: const EdgeInsets.all(7.0),
                                child: Icon(Icons.heart_broken_sharp,color: Colors.white),
                              ),
                            )
                          ],
                        ),
                        Spacer(),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "124 bpm",
                              style: TextStyle(fontSize: 20,color: Colors.white),
                            ),
                          ],
                        ),
                        Spacer(),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Column(
                              children: [
                                Text("80-120",style: TextStyle(color: Colors.white)),
                                Text("Healthy",style: TextStyle(color: Colors.white),),
                              ],
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Spacer(),
                Container(
                  height: 160,
                  width: 160,
                  decoration: BoxDecoration(
                      color: Colors.red[400],
                      borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding:
                        const EdgeInsets.only(left: 8.0, right: 8, bottom: 8),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Text(
                              "Sleep",
                              style:
                                  TextStyle(fontSize: 13, color: Colors.white),
                            ),
                            Spacer(),
                            Container(
                              decoration: BoxDecoration(
                                  color: Color.fromARGB(31, 221, 213, 213),
                                  borderRadius: BorderRadius.circular(50)),
                              child: Padding(
                                padding: const EdgeInsets.all(7.0),
                                child:
                                    Icon(Icons.mode_night, color: Colors.white),
                              ),
                            )
                          ],
                        ),
                        Spacer(),
                        Row(
                          children: [
                            Text(
                              "8 h 42 m",
                              style:
                                  TextStyle(fontSize: 20, color: Colors.white),
                            ),
                          ],
                        ),
                        Spacer(),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Column(
                              children: [
                                Text(
                                  "Deep Sleep",
                                  style: TextStyle(color: Colors.white),
                                ),
                                Text(
                                  "5 h 13 m",
                                  style: TextStyle(color: Colors.white),
                                )
                              ],
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
