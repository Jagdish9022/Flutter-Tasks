import 'package:flutter/material.dart';

import 'package:animated_notch_bottom_bar/animated_notch_bottom_bar/animated_notch_bottom_bar.dart';

class Home extends StatelessWidget {
  List data = [
    [
      Color.fromARGB(255, 252, 251, 209),
      Colors.yellow,
      "Identity proofs ",
      "9 Document(s)"
    ],
    [
      Color.fromARGB(255, 205, 225, 241),
      Colors.blue,
      "Certification",
      "12 Documents(s)"
    ],
    [
      Color.fromARGB(255, 229, 198, 208),
      Colors.pink,
      "Immunizations",
      "3 Documents(s)"
    ],
    [
      const Color.fromARGB(255, 238, 202, 244),
      Colors.purple,
      "References",
      "7 Documents(s)"
    ],
    [
      Color.fromARGB(255, 205, 225, 241),
      Colors.blue,
      "Licensure",
      "4 Documents(s)"
    ],
    [
      const Color.fromARGB(255, 198, 237, 200),
      Colors.green,
      "Degrees",
      "2 Documents(s)"
    ]
  ];

  NotchBottomBarController _controller =NotchBottomBarController();

  Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        leading: Icon(
          Icons.account_circle_sharp,
          size: 40,
          color: Colors.white,
        ),
        title: Text(
          "DocuVault",
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        actions: [
          Icon(
            Icons.share,
            color: Colors.white,
          ),
          SizedBox(
            width: 20,
          ),
          Icon(
            Icons.notifications,
            color: Colors.white,
          ),
          SizedBox(
            width: 20,
          ),
          Icon(
            Icons.search,
            color: Colors.white,
          ),
          SizedBox(
            width: 20,
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              "All Credentials",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
            ),
          ),
          GridView.builder(
            shrinkWrap: true,
            itemCount: data.length,
            gridDelegate:
                SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
            itemBuilder: (context, index) {
              return Padding(
                  padding: const EdgeInsets.all(9.0),
                  child: Container(
                    decoration: BoxDecoration(
                        border: Border.all(),
                        borderRadius: BorderRadius.circular(13)),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                decoration: BoxDecoration(
                                    color: data[index][0],
                                    borderRadius: BorderRadius.circular(12)),
                                child: Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: Icon(
                                    Icons.folder,
                                    size: 40,
                                    color: data[index][1],
                                  ),
                                ),
                              ),
                            ),
                            Text(
                              data[index][2],
                              style: TextStyle(
                                  fontSize: 22, color: Colors.blue[900]),
                            ),
                            Text(
                              data[index][3],
                              style: TextStyle(
                                  fontSize: 19, fontWeight: FontWeight.w300),
                            )
                          ],
                        ),
                      ),
                    ),
                  ));
            },
          ),
          SizedBox(height: 0,),
        ],
      ),
      
      bottomNavigationBar: _bottomappbar(),
    );
  }

  _bottomappbar() {
    return AnimatedNotchBottomBar(
      notchBottomBarController: _controller,
      color: Colors.white,
      showLabel: true,
      textOverflow: TextOverflow.visible,
      maxLine: 1,
      shadowElevation: 5,
      kBottomRadius: 28.0,
      notchColor: Colors.black87,
      removeMargins: false,
      bottomBarWidth: 500,
      showShadow: false,
      durationInMilliSeconds: 300,
      itemLabelStyle: const TextStyle(fontSize: 10),
      elevation: 1,
      bottomBarItems: const [
        BottomBarItem(
          inActiveItem: Icon(
            Icons.dashboard,
            color: Colors.black,
          ),
          activeItem: Icon(
            Icons.dashboard,
            color: Colors.blueAccent,
          ),
          itemLabel: '',
        ),
        BottomBarItem(
          inActiveItem: Icon(Icons.star, color: Colors.blueGrey),
          activeItem: Icon(
            Icons.work,
            color: Colors.black,
          ),
          itemLabel: '',
        ),
        BottomBarItem(
          inActiveItem: Icon(
            Icons.add,
            color: Colors.blueGrey,
          ),
          activeItem: Icon(
            Icons.add,
            color: Colors.blue,
          ),
          itemLabel: '',
        ),
        BottomBarItem(
          inActiveItem: Icon(
            Icons.work,
            color: Colors.blueGrey,
          ),
          activeItem: Icon(
            Icons.work,
            color: Colors.yellow,
          ),
          itemLabel: '',
        ),
        BottomBarItem(
          inActiveItem: Icon(
            Icons.person_add_alt_1_outlined,
            color: Colors.blueGrey,
          ),
          activeItem: Icon(
            Icons.person,
            color: Colors.yellow,
          ),
          itemLabel: '',
        ),
      ],
      onTap: (index) {},
      kIconSize: 24.0,
    );
  }
}
