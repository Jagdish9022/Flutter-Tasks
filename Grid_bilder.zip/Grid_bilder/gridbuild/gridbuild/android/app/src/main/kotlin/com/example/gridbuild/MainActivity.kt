package com.example.gridbuild

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
