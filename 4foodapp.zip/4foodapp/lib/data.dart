List data=[
  ['https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRvLdCdM4vI1YyN_iYrqf4Gfj-0g2hJMzx2pg&s','orange',"5.0",'590 g', 12.00],
  ['https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuTFKE7njYVRh7BvivU4SeTI6sStDCWMm-8w&s','Red apples',"4.9",'350 g', 4.00],
  ['https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT-4fuljx8K0OCOgrWlXJmyxUMQ2RRXRZCHUQ&s','mango',"5.0",'890 g', 16.00],
 
];