import 'package:flutter/material.dart';

import 'builder.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.place,
                        size: 25,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Express delivery",
                            style: TextStyle(color: Colors.grey[400]),
                          ),
                          Text(
                            "Deepolie Street,42",
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w900),
                          )
                        ],
                      ),
                    ],
                  ),
                  Row(
                    children: [

                      IconButton(
                          onPressed: () {},
                          icon: Icon(
                            Icons.search_outlined,
                            size: 30,
                          )),
                      IconButton(
                          onPressed: () {},
                          icon: Icon(
                            Icons.notifications_none_outlined,
                            size: 30,
                          ))
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: Container(
                height: 50,
                width: double.infinity,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: Colors.grey[300]),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                            width: 150,
                            height: double.infinity,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15)),
                            child: Center(child: Text("Delivery"))),
                      ),
                      Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15)),
                            width: 150,
                            height: double.infinity,
                            child: Center(child: Text('Shop')),
                          ))
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Container(
                height: 130,
                width: double.infinity,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    image: DecorationImage(
                        image: NetworkImage(
                            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRljlgySVsZMjgCo3vePHbicl3Ir_kj5vkAWg&s'),
                        fit: BoxFit.cover)),
                child: Column(
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12.0, vertical: 4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Level 2 in june",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900),
                            ),
                            Text(
                              "8% on your pavourite product",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w900),
                            )
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              height: 30,
                              width: 120,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(25)),
                              child: Center(
                                  child: Text(
                                "1,300 bounus",
                                style: TextStyle(
                                    fontSize: 15, fontWeight: FontWeight.w900),
                              )),
                            ),
                            Container(
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(50)),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Icon(Icons.arrow_forward_ios),
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Novelties of the week",
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
                  ),
                  Text(
                    "See all",
                    style: TextStyle(color: Colors.green[400], fontSize: 19),
                  )
                ],
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Build(),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: 150,
                      width: 180,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Stack(children: [
                          Align(
                                alignment: Alignment.topRight,
                                child: Container(
                                  height: 90,
                                  width: 60,
                                  
                                  child: Image(image: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzojxjclj_4ioTHYYPCj66BQH1Th2zJekLxw&s')),
                                ),
                              ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text("Prepared\nfood",style: TextStyle(fontSize: 21,fontWeight: FontWeight.w900),))]),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: 150,
                      width: 180,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                      ),
                       child: Padding(
                         padding: const EdgeInsets.all(8.0),
                         child: Stack(
                           children: [
                            Align(
                                alignment: Alignment.topRight,
                                child: Container(
                                  height: 90,
                                  width: 60,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50)
                                  ),
                                  child: Image(image: NetworkImage('https://images.herzindagi.info/image/2024/Jan/Grilled-Vegetable-Salad.jpg')),
                                ),
                              ),
                             Align(
                              alignment: Alignment.topLeft,
                              child: Text("Meat and\nPolutry",style: TextStyle(fontSize: 21,fontWeight: FontWeight.w900),)),
                              
                           ],
                         ),
                       ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
      bottomNavigationBar: Container(
        height: 60,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,

        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Icon(Icons.home,size: 40,),
            Icon(Icons.wallet,size: 40,),
            Icon(Icons.lock,size: 40,),
            Icon(Icons.favorite_outline,size: 40,),
            Icon(Icons.person,size: 40,),
          ],
        ),
      ),
    );
  }
}
